from sklearn import liner_model

reg = linear_model.LinearRegression()

X = [[0, 0], [1, 1], [2, 2]]
Y = [0, 1, 2]

reg.fit(X, Y)

reg.predict([[1, 3]])
